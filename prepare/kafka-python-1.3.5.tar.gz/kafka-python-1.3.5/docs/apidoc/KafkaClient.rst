KafkaClient
===========

.. autoclass:: kafka.client.KafkaClient
    :members:
