# Project/People/Companies using kafka-python

If you're using this library and care to give us a shout out, please fork the project,
add yourself here, and submit a pull request. Thanks!

* [@mumrah](https://github.com/mumrah), adding myself as an example
